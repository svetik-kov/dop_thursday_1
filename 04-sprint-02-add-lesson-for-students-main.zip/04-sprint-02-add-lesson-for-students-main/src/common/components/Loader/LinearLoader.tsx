import s from './Loader.module.css'

export const LinearLoader = () => {
  return <div className={s.linearLoader}></div>
}
